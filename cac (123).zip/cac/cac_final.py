from typing import Union

import numpy as np
import seaborn as sns
import pandas as pd
from tqdm import tqdm
from line_profiler_pycharm import profile
from utils.utils import bfs, graph, find_maximized_connected_subgraphs, get_data, partition_arg_topK, customCDF
from scipy.spatial import distance as dis
from matplotlib import pyplot as plt
from collections import OrderedDict
from utils.color_marker import get_pms


class CAC(object):
    def __init__(self, data,
                 max_iter: int = -1,
                 K: int = 20,
                 max_del_point: int = -1,
                 link_threshold: int = -1,
                 def_cnum: int = 20,
                 lr: float = 1e-0,
                 ftype: Union[str, None] = None,
                 cdf_threshold: float = 0.95,
                 sum_prob: float = -1,
                 distance_=None,
                 *args, **kwargs):
        self.src_data = data
        self.init_ = True
        self.K = min(len(data) - 1, K)
        self.N = len(self.src_data)
        self.cdf_threshold_ = cdf_threshold
        self.W = 1
        self.min_error = 1e-10
        self.lr = lr
        self.max_del_point = max_del_point if max_del_point > 0 else -1
        self.ftype = ftype if ftype is not None else ('random' if self.max_del_point > 0 else 'max')
        self.min_valuable_custer = 5
        self.def_cnum = def_cnum

        if distance_ is None:
            self.__distance_matrix = dis.squareform(dis.pdist(self.src_data, lambda u, v: np.sum(np.power(u - v, 2))))
        else:
            print('init distance')
            self.__distance_matrix = distance_

        self.__distance_matrix = np.where(self.__distance_matrix == 0, np.inf, self.__distance_matrix)

        distance_top_k = partition_arg_topK(self.__distance_matrix, self.K, axis=1)
        self.__out_adjacency_matrix = distance_top_k.copy()

        if link_threshold <= 0:
            nk = 5

            cluster_adj_num = OrderedDict()
            cluster_num = self.N
            while True:
                subgraph_set, _ = find_maximized_connected_subgraphs(self.OAM[:, :nk], self.OAM)
                if len(subgraph_set) < cluster_num:
                    # cluster_adj_num += [nk]
                    cluster_adj_num[nk] = len(subgraph_set)
                    cluster_num = len(subgraph_set)
                if len(subgraph_set) <= 1 or nk >= self.K:
                    break
                nk += 1

            cluster_adj_num_keys = list(cluster_adj_num.keys())
            self.link_threshold = int(
                np.mean(cluster_adj_num_keys[-2:]) if cluster_adj_num_keys[-1] >= self.K
                else cluster_adj_num_keys[-1])
        else:
            self.link_threshold = link_threshold
            nk = self.link_threshold
        self.K = max(nk, link_threshold)

        self.__out_adjacency_matrix = self.OAM[:, :self.K]
        self.__in_adjacency_matrix = [np.where(self.OAM == i) for i in
                                      range(self.N)]  # no duplicate row, only one di-edge between a (u, v) pair
        max_in_neighbors = max(*[len(i[0]) for i in self.IAM])
        self.cc_onehot = np.eye(max_in_neighbors, dtype=int)

        self.mus, self.stds = np.ones((self.N, 1)) * self.PD.min(axis=1, keepdims=True), np.ones(
            (self.N, 1)) * 1e-5  # n*1
        self.def_mus, self.def_stds = self.mus.copy(), self.stds.copy()

        self.p2idx = np.arange(self.N).reshape(self.N).astype(np.uint64)
        self.p2c = np.arange(self.N).reshape(self.N).astype(np.uint64)  # n
        self.p2scale = np.ones(shape=(self.N, 1), dtype=float) * 0.0001  # n*1

        self.max_iter = max_iter
        # the min distance's 1e-5/10^n times
        min_distance = self.PD.min() * 10 ** int(np.log10(1e-5 / self.PD.min())).__floor__()
        self.one_step = np.zeros((self.N, 1)) + min_distance

        self.k_neighbors_distance = self.PD[
            np.arange(0, self.N).reshape((-1, 1)).repeat(self.K, axis=1), self.OAM]  # N*K
        self.free_point = np.zeros((self.N, 1))  # N*1
        self.alive_points = np.ones((self.N, 1), dtype=np.bool_)
        self.emit_to_alive_points = None
        self.sum_prob = 10 / self.max_iter if sum_prob < 0 else sum_prob
        self.prior_starts = None

    @property
    def PD(self):
        return self.__distance_matrix

    @property
    def OAM(self) -> np.ndarray:
        return self.__out_adjacency_matrix

    @property
    def IAM(self) -> list:
        return self.__in_adjacency_matrix

    @profile
    def __get_conflictResult(self, one_step,
                             scales: np.ndarray[np.float64],
                             mus: np.ndarray[np.float64],
                             stds: np.ndarray[np.float64],
                             W: np.int64,
                             ):
        k_neighbors_mus = mus.reshape((-1, 1))  # N*1
        k_neighbors_stds = stds.reshape((-1, 1))  # N*1

        delta = (one_step * W + k_neighbors_mus * (1 - W)) * scales.reshape((-1, 1))  # N*K
        ubCDF = customCDF(self.k_neighbors_distance + delta, k_neighbors_mus, k_neighbors_stds, mode='nb')  # N*K
        lbCDF = customCDF(self.k_neighbors_distance - delta, k_neighbors_mus, k_neighbors_stds, mode='nb')  # N*K
        neighbors_scores_from_cluster = np.abs(ubCDF - lbCDF) + self.min_error  # N*K

        shift_threshold = 0.85
        neighbors_scores_from_cluster = np.where(neighbors_scores_from_cluster >= self.cdf_threshold_,
                                                 (neighbors_scores_from_cluster - self.cdf_threshold_) / (
                                                         1 - self.cdf_threshold_) * shift_threshold + (
                                                         1 - shift_threshold),
                                                 neighbors_scores_from_cluster / self.cdf_threshold_ * shift_threshold)

        adj_table = np.where(neighbors_scores_from_cluster >= shift_threshold,
                             neighbors_scores_from_cluster, -0 * neighbors_scores_from_cluster)  # N*K
        adj_table[adj_table[:, 0] < self.cdf_threshold_, 0] = self.cdf_threshold_
        G = graph(adj_table, self.OAM, self.IAM, self.max_del_point, self.ftype, self.sum_prob, self.prior_starts, [])

        scale_delta = self.link_threshold * shift_threshold - neighbors_scores_from_cluster[:,
                                                              :self.link_threshold].sum(axis=1, keepdims=True)
        return G, scale_delta

    @profile
    def calConflict(self, cluster_infos, one_step, p2scale, stage, debug, plot):
        G, delta_scale = self.__get_conflictResult(
            one_step,
            p2scale,
            self.mus,
            self.stds,
            self.W,
        )
        # block all edges linked to un-alive point
        if stage == 1:
            blocked_table = np.zeros_like(G.out_table_val)
            blocked_table[self.emit_to_alive_points[:, 0], self.emit_to_alive_points[:, 1]] = G.out_table_val[
                self.emit_to_alive_points[:, 0], self.emit_to_alive_points[:, 1]]
            G.out_table_val[:, :] = blocked_table

        cluster_set = list(bfs(G, self.p2c, self.free_point,
                               cluster_infos, self.cc_onehot, del_point_set=set(), debug=debug))
        idx = list(range(len(cluster_set)))
        np.random.shuffle(idx)

        tmp_clusterInfo = self.p2c.copy()
        if debug:
            plt.clf()
            result = pd.DataFrame(CAC.getResult(self.p2c, self.src_data),
                                  columns=['p', 'c', 'x', 'y'])
            data_xy = result.values[:, -2:]
            row, col = np.where(G.out_table_val == -1e-15)
            col = self.OAM[row, col]
            edges = np.asarray(list(zip(*(row, col))), dtype=int)
            tmp = data_xy[edges.flatten()].reshape(-1, 2, 2).swapaxes(1, 2).reshape(-1, 2)
            plt.plot(*tmp, linestyle="dotted", color='#5c2223')
            if plot is not None:
                plt.ylim((-0.1, 1.1))
                plt.xlim((-0.1, 1.1))
                plt.axis('off')
                plt.savefig(plot + '_dash.png', dpi=600, transparent=True)
                plt.clf()

            markers, sizes, palette = get_pms(list(cluster_infos.keys()))  # len(cluster_infos) > len(cluster_set)
            pv_list = list(palette.values())

        for i, cid in enumerate(idx):
            nodes = cluster_set[cid]
            if len(nodes) == 1:
                continue
            nodes = np.asarray(nodes)

            new_c = -1
            changed_nodes = nodes
            if stage == 1:
                dead_points = np.where(np.logical_not(self.alive_points[nodes]))[0]
                if len(dead_points) > 0:
                    new_c = self.p2c[np.random.choice(nodes[dead_points])]
                changed_nodes = nodes[self.alive_points[nodes].reshape(-1)]
            elif stage == 0:
                new_c = self.p2c[nodes[0]]
                if new_c not in nodes:  # independence
                    new_c = nodes[0]

            if new_c == -1:
                new_c = self.p2c[nodes[0]]
            tmp_clusterInfo[changed_nodes] = new_c

            if debug:
                row = G.bfstrees[cid]
                col = nodes[1:]

                edges = np.asarray([[r, c] for r, c in zip(*(row, col)) if c in nodes], dtype=int)
                tmp = data_xy[edges.flatten()].reshape(-1, 2, 2).swapaxes(1, 2).reshape(-1, 2)
                plt.plot(*tmp, linestyle="-", color=pv_list[i])

        if debug and (plot is not None):
            plt.ylim((-0.1, 1.1))
            plt.xlim((-0.1, 1.1))
            plt.axis('off')
            plt.savefig(plot + '_edges.png', dpi=600, transparent=True)
            plt.clf()

        self.p2c = tmp_clusterInfo
        if debug:
            # for idx, (x, y, c) in enumerate(result[['x', 'y', 'c']].values):
            #     plt.annotate(text='%i-%i' % (idx, c), xy=(x, y))
            sns.scatterplot(result, x='x', y='y', hue='c', palette=palette, style='c', markers=markers)
            if plot is not None:
                plt.ylim((-0.1, 1.1))
                plt.xlim((-0.1, 1.1))
                plt.axis('off')
                plt.gca().get_legend().remove()
                plt.savefig(plot, dpi=600, transparent=True)
            else:
                plt.draw()
                plt.pause(0.05)
        tmp_dict = {}
        for pid, cid in enumerate(self.p2c):
            if cid not in tmp_dict.keys():
                tmp_dict[cid] = []
            tmp_dict[cid].append(pid)

        # different stages
        if stage >= 0:
            loss = np.mean(delta_scale)
            self.p2scale += self.lr * loss
        else:
            loss = np.mean(delta_scale[self.alive_points])
            self.p2scale[self.alive_points] += self.lr * loss

        self.p2scale = self.p2scale.clip(self.min_error, np.inf)
        return loss, delta_scale, G

    def updatePattern(self):
        cluster_infos = {}
        for pid, cid in enumerate(self.p2c):
            if cid not in cluster_infos.keys():
                cluster_infos[cid] = []
            cluster_infos[cid].append(pid)

        self.free_point *= 0
        for k, v in cluster_infos.items():
            self.free_point[v] = len(v)
            if len(v) >= self.min_valuable_custer:  # for statistical significance
                member_min_distance = self.PD[v][:, v].min(axis=1)
                self.mus[v, :] = np.mean(member_min_distance)
                self.stds[v, :] = np.std(member_min_distance)
        return cluster_infos

    def cluster(self, debug=lambda x: False, plot=None, step_two=True):
        records_ = []
        with tqdm(range(self.max_iter)) as pbar:
            stage_tag = 0
            cluster_infos = self.updatePattern()
            for iter in pbar:
                loss, delta_scale, G = self.calConflict(cluster_infos, self.one_step, self.p2scale, debug=debug(iter),
                                                        stage=stage_tag, plot=plot + ('%d th' % iter))

                cluster_infos = self.updatePattern()
                pbar.set_description("Stage %d" % stage_tag)
                pbar.set_postfix({'loss': loss, 'clusters': len(cluster_infos), 'def_cnum': self.def_cnum},
                                 refresh=True)

                if step_two and iter >= self.max_iter * .9 and stage_tag == 0:
                    forced_agg_threshold = self.N / self.def_cnum if self.def_cnum > 0 else -1
                    dead_points_idx = (self.free_point > forced_agg_threshold)
                    if dead_points_idx.sum() == self.N:
                        pbar.set_postfix({'end loop': 'no alive_points'})
                        break
                    self.W = 0
                    self.alive_points[dead_points_idx] = False

                    # refresh the mus and stds for each node
                    for k, v in cluster_infos.items():
                        if len(v) > 1:
                            member_min_distance = self.PD[v][:, v].min(axis=1)
                            self.mus[v, :] = np.mean(member_min_distance)
                            self.stds[v, :] = np.std(member_min_distance)
                        else:
                            self.mus[v, :] = self.mus.mean()
                            self.stds[v, :] = 1e-5

                    self.p2scale = ((self.p2scale * self.one_step) / self.mus).max()

                    self.emit_to_alive_points = []
                    emit_source_points = set()
                    # add all out degrees from dead points which emit to alive points
                    emit_dead_points_count = {}
                    self.prior_starts = set()
                    avg_available_link = int(self.link_threshold / 2) if self.max_del_point > 0 else self.link_threshold
                    for i in np.where(self.alive_points.ravel())[0]:
                        emit_source_points.add(i)
                        self.prior_starts |= set(
                            [j for j in self.IAM[i][0] if not self.alive_points[j]])  # add all dead points

                        emit_source_points |= set(self.IAM[i][0])
                        emit_to_alive_point_set = set([j for j, k in zip(self.IAM[i][0], self.IAM[i][1])
                                                       if k < avg_available_link and (self.p2c[i] != self.p2c[
                                j])])  # consider all neighbors with the different cluster
                        if len(emit_to_alive_point_set) > 0:
                            if self.p2c[i] not in emit_dead_points_count.keys():
                                emit_dead_points_count[self.p2c[i]] = {}
                            if i not in emit_dead_points_count[self.p2c[i]].keys():
                                emit_dead_points_count[self.p2c[i]][i] = set()
                            emit_dead_points_count[self.p2c[i]][i] |= emit_to_alive_point_set

                    blocked_emits = set()
                    for k, v in emit_dead_points_count.items():
                        conflict_prob = len(v) / len(cluster_infos[k])
                        if conflict_prob <= 0.1:
                            for vk, vv in v.items():
                                blocked_emits.update([(vvi, vk) for vvi in vv])
                    self.max_del_point = -1

                    for i in emit_source_points:
                        emit_edges = [(i, j) for j, k in enumerate(self.OAM[i, :avg_available_link])
                                      if (self.alive_points[k] and (i, k) not in blocked_emits)]
                        if len(emit_edges) > 0:
                            self.emit_to_alive_points.extend(emit_edges)
                    self.emit_to_alive_points = np.asarray(self.emit_to_alive_points)
                    stage_tag = 1
                    print()
                records_.append([iter, loss, len(set(cluster_infos.keys()) - {-1})])
            self.updatePattern()
            return records_

    @staticmethod
    def getResult(p2c, src_data, min_cluster=5) -> list:
        unique, counts = np.unique(p2c, return_counts=True)
        return [([pid, cid if counts[unique == cid] >= min_cluster else -1] + list(src_data[pid])) for pid, cid in
                enumerate(p2c)]
