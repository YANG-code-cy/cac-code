import os
from collections import namedtuple
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.lines import Line2D

from cac.cac_final import CAC
from cac.utils.color_marker import get_pms
from cac.utils.parameter_config import config
from sklearn import metrics

matplotlib.use('TkAgg', force=True)
print("Switched to:", matplotlib.get_backend())

import numpy as np
from utils.utils import get_data
import seaborn as sns
import tikzplotlib

datasets = [
    'compound', 'aggregation'
]

# 'compound': {'max_del_point': 5},

exp_name = f'exp#2/%s'

data_item = namedtuple('DataItem', ['m', 'stype', 'v'])

for i, data_set_name in enumerate(datasets):
    fig, ax = plt.subplots(1, 1, figsize=(4.5, 2))
    curve_data = []
    for j in range(0, 11):
        np.random.seed(1024)
        input_table = get_data(data_set_name)
        file = exp_name % data_set_name + '_m-%s' % str(j)
        if not os.path.exists(file):
            X = input_table[['x', 'y']].values
            kwargs = {'max_iter': 500}
            if data_set_name in config.keys():
                kwargs.update(config[data_set_name])

            kwargs['max_del_point'] = j
            print(kwargs)
            cac = CAC(X, **kwargs)
            cac.cluster(plot=data_set_name)

            result = CAC.getResult(cac.p2c, cac.src_data)
            result = pd.DataFrame(result, columns=['p', 'c', 'x', 'y'])
            result.to_csv(file)

        result = pd.read_csv(file)
        labels_true = input_table['c'].values.astype(np.int64)
        uclabels, labels = np.unique(result['c'].values, return_inverse=True)
        curve_data.append(data_item(j, 'nClusters', len(uclabels)))
        curve_data.append(data_item(j, 'Homogeneity', metrics.homogeneity_score(labels_true, labels)))
        curve_data.append(data_item(j, 'Completeness', metrics.completeness_score(labels_true, labels)))
        curve_data.append(data_item(j, 'V-measure', metrics.v_measure_score(labels_true, labels)))
        curve_data.append(data_item(j, 'Adjusted Rand Index', metrics.adjusted_rand_score(labels_true, labels)))
        curve_data.append(
            data_item(j, 'Adjusted Mutual Information', metrics.adjusted_mutual_info_score(labels_true, labels)))

    curve_table = pd.DataFrame(curve_data, columns=list(data_item._fields))
    legend = ['nClusters', 'Homogeneity', 'Completeness', 'V-measure', 'Adjusted Rand Index',
              'Adjusted Mutual Information']
    markers, sizes, palette = get_pms(legend)
    # g = sns.lineplot(curve_table, x='m', y='v', hue='stype', ax=ax,
    #                  palette=palette, markers=markers,
    #                  style='stype')
    # g.set_title(data_set_name)

    ax2 = ax.twinx()
    ylim1 = [np.inf, -np.inf]
    ylim2 = [np.inf, -np.inf]
    for k in legend:
        data = curve_table.query('stype=="%s"' % k)
        mm = data['v'].min() * 0.9
        ma = data['v'].max() * 1.1
        if k in {'nClusters'}:
            p = ax2
            ylim2 = [min(ylim2[0], mm), max(ylim2[1], ma)]
        else:
            p = ax
            ylim1 = [min(ylim1[0], mm), max(ylim1[1], ma)]
        p.plot(data['m'], data['v'], color=palette[k], marker=markers[k],
               linewidth=2, markersize=5, label=k)
    ax.set_ylim(ylim1)
    ax2.set_ylim(ylim2)
    ax.set_yticks(np.arange((round(ylim1[0] * 10)/10), ylim1[1], 0.2))
    ax2.set_yticks(np.arange((round(ylim2[0])), ylim2[1], 2))
    ax.set_xlabel('delete')
    ax.set_ylabel('Scores')
    ax2.set_ylabel('n Clusters')
    lines, labels = ax.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax.legend(lines + lines2, labels + labels2, loc='best')
    # tikzplotlib.save(exp_name % data_set_name + '.tex', encoding='utf-8')
    plt.savefig(exp_name % data_set_name + '.png', dpi=600, transparent=False)
    plt.show()
