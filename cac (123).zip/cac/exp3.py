import os
from collections import namedtuple
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.lines import Line2D

from cac.cac_final import CAC
from cac.utils.color_marker import get_pms
from cac.utils.parameter_config import config
from sklearn import metrics

matplotlib.use('TkAgg', force=True)
print("Switched to:", matplotlib.get_backend())

import numpy as np
from utils.utils import get_data
import seaborn as sns
import tikzplotlib

datasets = [
    'jain', '3-spiral', 'smile3',
    'triangle1', 'spherical_6_2', 'twenty',
    'compound', 'aggregation'
]

exp_name = f'exp#3/%s'
max_iters = [100, 200, 500, 1000, 2000, 5000, ]
curves_data = []
losses_data = []
for i, data_set_name in enumerate(datasets):
    loss_data = []
    for mii, j in enumerate(max_iters):
        np.random.seed(1024)
        input_table = get_data(data_set_name)
        file = exp_name % data_set_name + '_iter-%s' % str(j)
        if not os.path.exists(file):
            X = input_table[['x', 'y']].values
            kwargs = {'max_iter': j}
            if data_set_name in config.keys():
                kwargs.update(config[data_set_name])
            print(kwargs)
            cac = CAC(X, **kwargs)
            records_ = cac.cluster(plot=data_set_name)

            result = CAC.getResult(cac.p2c, cac.src_data)
            result = pd.DataFrame(result, columns=['p', 'c', 'x', 'y'])
            result.to_csv(file)
            loss_data += [[(iter + 1) / j * 100, loss, j] for iter, loss, cnum in records_]

        result = pd.read_csv(file)  # n_cluster_with maxiter
        curves_data.append(
            [mii, data_set_name, len(result.query('c!=-1')['c'].unique()),
             int(len(result.query('c==-1')))])

    if not os.path.exists(exp_name % data_set_name + '_loss'):
        loss_table = pd.DataFrame(loss_data, columns=['Process (%)', 'Loss', 'MaxIter'])
        loss_table.to_csv(exp_name % data_set_name + '_loss')

    loss_table = pd.read_csv(exp_name % data_set_name + '_loss')
    losses_data += list(item for item in zip(*[loss_table['Process (%)'],
                                               loss_table['Loss'],
                                               data_set_name + ":" + loss_table['MaxIter'].astype(str),
                                               [data_set_name] * len(loss_table)])
                        if item[0].is_integer() and (item[0] == 1 or item[0] % 10 == 0))

curves_table = pd.DataFrame(curves_data, columns=['MaxIter', 'DataSets', 'Valid Clusters', 'Unlabeled Points'])
fig, axes = plt.subplots(nrows=3, ncols=3, figsize=(17, 8))
markers, sizes, palette = get_pms(datasets)

ax = axes[0, 0]
for data_set_name in datasets:
    data = curves_table.query('DataSets=="%s"' % data_set_name)
    ax.plot(data['MaxIter'], data['Valid Clusters'], color=palette[data_set_name], marker=markers[data_set_name],
            linewidth=2, markersize=5, label=data_set_name)
    ax.set_yticks(list(range(1, 10, 2)))
    ax.set_xticks(range(len(max_iters)))
    ax.set_xticklabels([str(mi) for mi in max_iters])
    ax.set_xlabel('MaxIter')
    ax.set_ylabel('Valid Clusters')
ax.legend(loc='best')

ax = axes[2, 2]
for data_set_name in datasets:
    data = curves_table.query('DataSets=="%s"' % data_set_name)
    ax.plot(data['MaxIter'], data['Unlabeled Points'], color=palette[data_set_name], marker=markers[data_set_name],
            linewidth=2, markersize=5, label=data_set_name)
    ax.set_yticks(list(range(0, 10, 2)))
    ax.set_xticks(range(len(max_iters)))
    ax.set_xticklabels([str(mi) for mi in max_iters])
    ax.set_xlabel('MaxIter')
    ax.set_ylabel('Unlabeled Points')
ax.legend(loc='best')
# tikzplotlib.save(exp_name % data_set_name + '_curve.tex', encoding='utf-8')
# plt.savefig(exp_name % data_set_name + '_curve.png', dpi=600, transparent=False)
# plt.show()


losses_table = pd.DataFrame(losses_data, columns=['Processing (%)', 'Delta', 'Hue', 'DataSets'])
# fig, ax = plt.subplots(figsize=(4.5, 2))
# hue = losses_table['Hue'].unique()
markers, sizes, palette = get_pms(max_iters)

for idx, data_set_name in enumerate(datasets):
    _row, _col = (idx + 1) // 3, (idx + 1) % 3
    ax = axes[_row, _col]
    for h in max_iters:
        data = losses_table.query('Hue=="%s"' % (data_set_name + ":" + str(h)))
        ax.plot(data['Processing (%)'], data['Delta'], color=palette[h], marker=markers[h],
                linewidth=2, markersize=5, label=str(h))
        ax.set_title(data_set_name)
        # ax.set_yticks(list(range(1, 10, 3)))
        # ax.set_xticks(range(len(max_iters)))
        # ax.set_xticklabels([str(mi) for mi in max_iters])
        ax.set_xlabel('Processing (%)')
        ax.set_ylabel('Delta')

ax.legend(loc='best')
tikzplotlib.save(exp_name % '_loss.tex', encoding='utf-8')
plt.savefig(exp_name % '_loss.png', dpi=600, transparent=False)
plt.show()
#
