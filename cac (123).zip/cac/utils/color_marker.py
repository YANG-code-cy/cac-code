import numpy as np
import seaborn as sns

markers = ['o', '+', 'x', 's', 'p']
anyuzi = '#5c2223'  # 暗玉紫
xiangyehong = '#f07c82'  # 香叶红
yuhong = '#c04851'  # 玉红
manjianghong = '#a7535a'  # 满江红
hehuanhong = '#f0a1a8'  # 合欢红
xiancaihong = '#a61b29'  # 苋菜红
yanhong = '#894e54'  # 烟红
zhuganzi = '#541e24'  # 猪肝紫
shanchahong = '#ed556a'  # 山茶红
xinhui = '#7a7374'  # 锌灰
gudinghui = '#36292f'  # 古鼎灰
luolanzi = '#c08eaf'  # 萝兰紫
shayuhui = '#35333c'  # 沙鱼灰
yanhanlan = '#131824'  # 燕颔蓝
jingtailan = '#2775b6'  # 景泰蓝
huaqing = '#2376b7'  # 花青
xinglan = '#93b5cf'  # 星蓝
yushandoulan = '#619ac3'  # 羽扇豆蓝
yinyubai = '#cdd1d3'  # 银鱼白
yuqinlan = '#126e82'  # 玉鈫蓝
shilv = '#57c3c2'  # 石绿
zhulv = '#1ba784'  # 竹绿
shenhailv = '#1a3b32'  # 深海绿
feiquanlv = '#497568'  # 飞泉绿
wuzhilv = '#69a794'  # 梧枝绿
wasonglv = '#6e8b74'  # 瓦松绿
ialingshuilv = '#add5a2'  # 嘉陵水绿
luweilv = '#b7d07a'  # 芦苇绿
pingguolv = '#bacf65'  # 苹果绿
xiangyabai = '#fffef8'  # 象牙白
foshouhuang = '#fed71a'  # 佛手黄
tanshuilv = '#645822'  # 潭水绿
maiganhuang = '#f8df70'  # 麦秆黄
xiangshuimeiguihuang = '#f7da94'  # 香水玫瑰黄
ezhanghuang = '#fbb929'  # 鹅掌黄
mihuang = '#fbb957'  # 蜜黄
xiekehong = '#f27635'  # 蟹壳红
taohong = '#f0ada0'  # 桃红
liuzihong = '#f1908c'  # 榴子红
diaozi = '#5d3131'  # 貂紫

def_palette = [diaozi, mihuang, taohong, maiganhuang,
               xiekehong, shayuhui, luolanzi, xinglan,
               yuhong, manjianghong]
def_palette = sns.color_palette('Set2', 8)
def_markers = ['o', 'P', '8', 'v', 's', 'X', '*', 'D']
def_marker2size_map = dict([(m, 50.) for m in def_markers])


# palette = seaborn.color_palette('Set2', 10)

def get_pms(uni_color):
    markers, sizes, palette = dict(), dict(), dict()
    palette[-1] = wasonglv
    markers[-1] = 'X'
    sizes[-1] = def_marker2size_map['X']
    for i, c in enumerate([i for i in uni_color if i != -1]):
        markers[c] = 'X' if c == -1 else def_markers[i // len(def_palette) % len(def_markers)]
        sizes[c] = None if c not in def_marker2size_map.keys() else def_marker2size_map[c]
        palette[c] = wasonglv if c == -1 else def_palette[i % len(def_palette)]
    return markers, sizes, palette
