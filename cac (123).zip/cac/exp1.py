import os
from typing import Union
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd

from cac.cac_final import CAC
from cac.utils.color_marker import get_pms
from cac.utils.parameter_config import config

matplotlib.use('TkAgg', force=True)
print("Switched to:", matplotlib.get_backend())

import numpy as np
from utils.utils import get_data
import seaborn as sns

datasets = [
    '3-spiral', 'smile3', 'jain',
    'triangle1', 'twenty',
    'compound', 'aggregation', 'spherical_6_2'
            ]

# fig, axes = plt.subplots(3, 3, figsize=(18, 10))
for i, data_set_name in enumerate(datasets):
    fig, axes = plt.subplots(1, 1, figsize=(2.25, 2))
    file = 'exp#1/%s' % data_set_name
    if not os.path.exists(file):
        np.random.seed(1024)
        input_table = get_data(data_set_name)
        X = input_table[['x', 'y']].values
        kwargs = {'max_iter': 500}
        if data_set_name in config.keys():
            kwargs.update(config[data_set_name])
        cac = CAC(X, **kwargs)
        cac.cluster(plot=data_set_name)

        result = CAC.getResult(cac.p2c, cac.src_data)
        result = pd.DataFrame(result, columns=['p', 'c', 'x', 'y'])
        result.to_csv(file)

    result = pd.read_csv('exp#1/%s' % data_set_name)
    # ax = axes[i // len(axes[0])][i % len(axes[0])]
    ax = axes
    markers, sizes, palette = get_pms(result['c'].unique())
    sns.scatterplot(result, x='x', y='y', hue='c', ax=ax,
                    palette=palette, markers=markers,
                    style='c')
        # .set_title(data_set_name)
    ax.axis('off')
    # ax.set_frame_on(False)
    # ax.get_xaxis().set_ticks([])
    # ax.get_yaxis().set_ticks([])
    ax.legend().set_visible(False)
    plt.draw()
    plt.pause(0.1)
    plt.savefig('exp#1/%s.png' % data_set_name, dpi=600, transparent=False)
    # plt.show()


