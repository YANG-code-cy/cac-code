config = {
    'flame': {'max_del_point': 2},
    'compound': {'max_del_point': 5},
    'aggregation': {'max_del_point': 5},
    'complex9': {'lr': 1e-1},
    'frey_rawface': {},
    'olivettifaces': {},
    'binaryalphadigs': {},
}
