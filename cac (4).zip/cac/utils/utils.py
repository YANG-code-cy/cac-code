import operator
from collections import namedtuple
import networkx as nx
import numba as nb
from line_profiler_pycharm import profile
from numba.core.utils import OrderedSet
import os.path
from typing import Optional
import numpy as np
import pandas as pd
from scipy.io import arff
import glob

graph = namedtuple('Graph', ['out_table_val', 'out_table_nei', 'in_table_info',
                             'max_del_point', 'ftype', 'sum_prob', 'prior_starts', 'bfstrees'])


@profile
def bfs(G: graph, p2c, p2c_num, c2p, cc_onehot, del_point_set=None, debug=False):
    ftype = G.ftype
    out_table_val = G.out_table_val
    N, K = out_table_val.shape
    out_table_nei = G.out_table_nei.copy()
    in_table_info = G.in_table_info.copy()
    out_table_tag = out_table_val > 0
    max_del_point = G.max_del_point

    block_tag = G.max_del_point > 0 and del_point_set is not None
    del_record_mat = np.zeros((N, N), dtype=int)

    c2pset = [set(c2p[i]) if i in c2p.keys() else set() for i in range(N)]
    nodes2out_deg = out_table_tag.sum(axis=1)
    starts = np.where(nodes2out_deg > 0)[0]
    starts = OrderedSet(starts[np.argsort(nodes2out_deg[starts])[::-1]])  # order by out degree
    prior_starts = G.prior_starts
    if prior_starts is not None:
        starts -= prior_starts
        prior_starts = list(prior_starts)
        np.random.shuffle(prior_starts)
        starts = OrderedSet(prior_starts) | starts
    visited = np.zeros(N, bool)

    for node in starts:
        if visited[node]:
            continue
        queue = []
        queue_row = []
        queue_col = []
        visited[node] = True
        queue.append(node)
        idx = 0
        while idx < len(queue):
            m = queue[idx]
            out_neighbours = out_table_nei[m, out_table_tag[m]]
            visited_tag = np.logical_not(visited[out_neighbours])

            if block_tag:
                for ii, nn in enumerate(out_neighbours):
                    in_neighbours, in_table_loc = in_table_info[nn]
                    in_nei_val = out_table_val[in_neighbours, in_table_loc]

                    link_tag = in_nei_val > 0
                    in_neighbours = in_neighbours[link_tag]
                    neighbours_clusters = p2c[in_neighbours]
                    uni_cluster_test = neighbours_clusters[0]
                    ret = set(in_neighbours).issubset(c2pset[uni_cluster_test])
                    if ret:
                        continue

                    in_nei_val = in_nei_val[link_tag]

                    if ftype == 'random':
                        # the probability according to the input deg ?
                        ftype = 'sum' if np.random.random() > G.sum_prob else 'max'

                    if ftype == 'max':
                        max_nei_id = np.random.choice(np.argwhere(in_nei_val == np.amax(in_nei_val)).reshape(-1))
                        max_c = neighbours_clusters[max_nei_id]

                    if ftype == 'sum':
                        uni_ncs, uni_inv = return_inverse(neighbours_clusters)
                        tmp = cc_onehot[uni_inv]
                        in_c = np.dot(in_nei_val, tmp)
                        max_c = uni_ncs[in_c.argmax()]

                    if min(del_record_mat[p2c[nn], max_c],
                           del_record_mat[max_c, p2c[nn]]) >= max_del_point:
                        continue

                    in_points = set(in_neighbours)
                    del_in_points = np.asarray(
                        list(in_points - set(c2p[max_c]) - del_point_set)
                    )
                    if len(del_in_points) > 0:
                        del_neg_tag_row, del_neg_tag_col = np.where(out_table_nei[del_in_points] == nn)
                        out_table_tag[del_in_points[del_neg_tag_row], del_neg_tag_col] = False
                        out_table_val[del_in_points[del_neg_tag_row], del_neg_tag_col] = -1e-15

                        del_in_points = del_in_points[p2c_num[del_in_points].ravel() > 1]
                        del_record_mat[p2c[del_in_points], p2c[nn]] += 1
                        if p2c_num[nn] <= 5:
                            # in degrees have been deleted,
                            # and now we need to prevent the out degree from being deleted
                            # for points that have not formed clusters
                            del_point_set.add(nn)

                    if max_c != p2c[node]:
                        visited_tag[ii] = False  # un-visitable

                    if max_c != p2c[nn]:
                        out_points = set(out_table_nei[nn])
                        del_out_points = np.asarray(
                            list(out_points - set(c2p[max_c]))
                        )
                        if len(del_out_points) > 0:  # cluster changed, block all out edge
                            out_table_tag[nn, :] = False
                            out_table_val[nn, :] = -1e-15

                            del_out_points = del_out_points[p2c_num[del_out_points].ravel() > 1]
                            del_record_mat[p2c[nn], p2c[del_out_points]] += 1

            visited_out_neighbours = out_neighbours[visited_tag]
            queue_row += [m] * len(visited_out_neighbours)
            queue += visited_out_neighbours.tolist()
            visited[visited_out_neighbours] = True
            idx += 1
        if len(queue) > 1:
            if debug:
                G.bfstrees.append(queue_row)
            yield queue


def find_maximized_connected_subgraphs(adj_table, AM, G=None):
    if G is None:
        G = nx.DiGraph()
        rows, cols = np.where(adj_table > 0)
        for r, c in zip(rows.tolist(), cols.tolist()):
            G.add_edge(r, AM[r, c])
    connected_components = nx.connected_components(G.to_undirected())
    return [np.asarray(list(component)) for component in connected_components if len(component) > 1], G


@nb.njit('(uint64[:],)', fastmath=True, parallel=False)
def return_inverse(x):
    maxnum = x.max() + 1  # Determines extent of indexing array
    p = np.zeros(maxnum, dtype='b1')
    p[x] = 1

    p2 = np.empty(maxnum, dtype=np.uint64)
    c = p.sum()
    p2[p] = np.arange(c)
    out = p2[x]
    return np.where(p)[0], out


@nb.njit('(float64[:,:],)', fastmath=True, parallel=False)
def NNnb(x):
    INV_ROOT_2_PI = 0.3989422804014327
    a1 = 0.319381530
    a2 = -0.356563782
    a3 = 1.781477937
    a4 = -1.821255978
    a5 = 1.330274429
    g = 0.2316419

    k = 1.0 / (1.0 + g * np.abs(x))
    k2 = k * k
    k3 = k2 * k
    k4 = k3 * k
    k5 = k4 * k

    c = (a1 * k + a2 * k2 + a3 * k3 + a4 * k4 + a5 * k5)
    phi = c * np.exp(-x * x / 2.0) * INV_ROOT_2_PI
    phi = np.where(x >= 0, 1 - phi, phi)
    return phi


def NN(x):
    INV_ROOT_2_PI = 0.3989422804014327
    a1 = 0.319381530
    a2 = -0.356563782
    a3 = 1.781477937
    a4 = -1.821255978
    a5 = 1.330274429
    g = 0.2316419

    k = 1.0 / (1.0 + g * np.abs(x))
    k2 = k * k
    k3 = k2 * k
    k4 = k3 * k
    k5 = k4 * k

    c = (a1 * k + a2 * k2 + a3 * k3 + a4 * k4 + a5 * k5)
    phi = c * np.exp(-x * x / 2.0) * INV_ROOT_2_PI
    phi = np.where(x >= 0, 1 - phi, phi)
    return phi


def exp_approx(x):
    tmp = (1512775.3951951857 * x + (1072693248 - 60801))
    return tmp / 4294967296


def gauss_cdf_approx(x):
    INV_ROOT_2_PI = 0.3989422804014327
    a1 = 0.319381530
    a2 = -0.356563782
    a3 = 1.781477937
    a4 = -1.821255978
    a5 = 1.330274429
    g = 0.2316419

    k = 1.0 / (1.0 + g * np.abs(x))
    k2 = k * k
    k3 = k2 * k
    k4 = k3 * k
    k5 = k4 * k

    c = (a1 * k + a2 * k2 + a3 * k3 + a4 * k4 + a5 * k5)
    phi = c * exp_approx(-x * x / 2.0) * INV_ROOT_2_PI
    phi = np.where(x >= 0, 1 - phi, phi)
    return phi


def cdf_approx(x):
    a1, a2, a3, a4, a5, a6 = 0.49853924, 1.29275674, 0.00466944, -1.57373827, -0.00339565, 0.79439626
    x1 = x
    x2 = x ** 2
    x3 = x2 * x
    x4 = x2 * x2
    x5 = x4 * x1
    return a1 * x1 + a2 * x2 + a3 * x3 + a4 * x4 + a5 * x5 + a6


def customCDF(x, loc, sigma, mode='np'):
    # F(x)=Φ[(x-μ)/σ]
    sigma += 1e-10
    if mode == 'nb':
        return NNnb((x - loc) / sigma)
    elif mode == 'app':
        return gauss_cdf_approx((x - loc) / sigma)
    else:
        return NN((x - loc) / sigma)


def partition_arg_topK(matrix, K, axis=0):
    shape = matrix.shape
    if len(shape) == 1:
        matrix = np.reshape(matrix, (1,) + shape)
        axis = 1
    a_part = np.argpartition(matrix, K, axis=axis)

    if axis == 0:
        row_index = np.arange(matrix.shape[1 - axis])
        a_sec_argsort_K = np.argsort(matrix[a_part[0:K, :], row_index], axis=axis)
        ret = a_part[0:K, :][a_sec_argsort_K, row_index]
    else:
        column_index = np.arange(matrix.shape[1 - axis])[:, None]
        a_sec_argsort_K = np.argsort(matrix[column_index, a_part[:, 0:K]], axis=axis)
        ret = a_part[:, 0:K][column_index, a_sec_argsort_K]

    if len(shape) == 1:
        matrix = np.reshape(matrix, shape + (1,))
        ret = np.reshape(ret, (K,))
    return ret


def load_txt_by_np(path: str):
    return np.asarray(np.loadtxt(path))[:, :3]


def load_arff_by_sci(path: str):
    return lambda: arff.loadarff(open(path, encoding='utf8'))[0]


def dataset_register():
    pass


def get_data(name: str) -> Optional[pd.DataFrame]:
    assert name in dataset_name_map.keys(), "unknown dataset"
    data = dataset_name_map[name.lower()]()
    input_table = pd.DataFrame(data)
    input_table = input_table.rename(columns=dict((k, v) for k, v in zip(input_table.columns, ['x', 'y', 'c'])))
    input_table[['x', 'y']] = input_table[['x', 'y']] - input_table[['x', 'y']].min()
    input_table[['x', 'y']] = input_table[['x', 'y']] / input_table[['x', 'y']].max()
    return input_table


dataset_name_map = {
}
for file in glob.glob("D:\\papers\\codes\\ClusterNew2024\\" + "Clustering-Datasets\\02. Synthetic\\*.arff"):
    name = os.path.basename(file).lower()
    dataset_name_map[''.join(name.split('.')[:-1])] = load_arff_by_sci(file)


if __name__ == "__main__":
    print(return_inverse(np.asarray([1, 2, 2, 8, 8, 2, 1], dtype=np.uint64)))
    l1 = []
    l2 = []
    for i in np.arange(-5, 5, 0.01):
        l1.append(customCDF(i, 0, 1))
        l2.append(gauss_cdf_approx(i))

    import matplotlib.pyplot as plt

    plt.plot(l1, label='cdf')
    plt.plot(l2, label='app')
    plt.legend()
    plt.show()

    print(get_data('complex8'))