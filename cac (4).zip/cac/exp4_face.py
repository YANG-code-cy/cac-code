import os
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
from image_similarity_measures.quality_metrics import rmse, psnr, ssim, sam, issm, uiq, fsim
from sewar.full_ref import mse as semes, rmse as sermse, psnr as sepsnr, uqi as seuqi, ssim as sessim, ergas as seergas, scc as sescc, rase as serase, sam as sesam, msssim as semsssim, vifp as sevifp
from matplotlib.patches import Rectangle
from scipy.spatial import distance as dis
from skimage.metrics import structural_similarity, hausdorff_distance, normalized_mutual_information

from cac.cac_final import CAC
from cac.utils.color_marker import get_pms
from cac.utils.parameter_config import config

matplotlib.use('TkAgg', force=True)
print("Switched to:", matplotlib.get_backend())

import numpy as np
from utils.utils import get_data
import seaborn as sns
import scipy.io

face_datasets = {'frey_rawface': {'path': '03. Face', 'rows': 28, 'cols': 20, 'data': 'ff', 'reshape': lambda x: x.T,
                                  'filter': lambda x: x,
                                  'embedding': False,
                                   'markersize': 20},
                 'olivettifaces': {'path': '03. Face', 'rows': 64, 'cols': 64, 'data': 'faces',
                                   'reshape': lambda x: np.asarray([i.reshape((64, 64)).T for i in x.T]),
                                   'filter': lambda x: x,
                                   'embedding': False,
                                   'markersize': 100},
                 'binaryalphadigs': {'path': '04. Handwritten Digits', 'rows': 20, 'cols': 16, 'data': 'dat',
                                     'reshape': lambda x: np.asarray([i for i in x.flatten()]) * 255,
                                     'filter': lambda x: x,
                                     'embedding': False,
                                     'markersize': 40},
                 # 'umist_cropped': {'path': '03. Face', 'rows': 112, 'cols': 92, 'data': 'faces',
                 # 'reshape': lambda x: x.T},
                 # 'mnist_all': {'path': '04. Handwritten Digits', 'rows': 112, 'cols': 92, 'data': 'faces'},
                 # 'usps_all': {'path': '04. Handwritten Digits', 'rows': 16, 'cols': 16, 'data': 'data',
                 #              'reshape': lambda x: x.reshape((256, -1)).T.reshape(256, 16, 16)},
                 }

# for i, data_set_name in enumerate(['olivettifaces']):
for i, data_set_name in enumerate([
    'frey_rawface',
    'olivettifaces',
    'binaryalphadigs']):
    file = 'exp#4-face/%s' % data_set_name
    para_dict = face_datasets[data_set_name]
    input_table = scipy.io.loadmat(
        '..//Clustering-Datasets//%s//%s.mat' % (para_dict['path'], data_set_name))
    img_rows, img_cols = para_dict['rows'], para_dict['cols']

    ff = para_dict['reshape'](input_table[para_dict['data']]).reshape((-1, img_rows, img_cols))

    if not os.path.exists(file):
        np.random.seed(1024)
        ebd = para_dict['embedding']
        if ebd:
            ebd_map = scipy.io.loadmat(
                '..//Clustering-Datasets//%s//ebd-%s.mat' % (para_dict['path'], data_set_name))
            fff = np.asarray([ebd_map[str(i)] for i in range(len(ff))]).reshape((len(ff), 2))
            distance = dis.squareform(dis.pdist(fff, lambda u, v: np.mean(np.power(u-v, 2))))
        else:
            fff = np.zeros_like(ff, dtype=float)
            for idx, i in enumerate(ff):
                fff[idx] = para_dict['filter'](i)

            min_, max_ = fff.min(), fff.max()
            fff = np.asarray(((fff - min_) / (max_ - min_)) * 1, dtype=float)
            fff = fff.reshape((-1, img_rows * img_cols))
            distance = dis.squareform(dis.pdist(fff, lambda u, v: np.sqrt(np.mean((u-v)**2))))

        kwargs = {'max_iter': 5000, 'link_threshold': -1,
                  'distance_': distance,
                  # 'lr': 5e2,
                  'max_del_point': 10,
                  }
        if data_set_name in config.keys():
            kwargs.update(config[data_set_name])

        cac = CAC(data=ff, **kwargs)
        print(cac.link_threshold)
        records_ = cac.cluster(plot=data_set_name, step_two=False)

        result = CAC.getResult(cac.p2c, cac.src_data)
        result = pd.DataFrame(result)
        result.to_csv(file)

        # loss_data += [[(iter + 1) / j * 100, loss, j] for iter, loss, cnum in records_]
        result2 = pd.DataFrame([[data_set_name, iter, loss, cnum]
                                for iter, loss, cnum in records_],
                               columns=['Dataset', 'Iter', 'Loss', 'Cluster Number'])
        result2.to_csv(file+'_loss')

    result_table = pd.read_csv(file).values
    images = ff
    num_images = len(images)
    grid_size = int(np.ceil(np.sqrt(num_images)))
    fig, ax = plt.subplots(figsize=(12, 12))

    unic, ct = np.unique(result_table[:, 2], return_counts=True)
    le = np.power(10, np.ceil(np.log10(len(result_table))))
    sorted_cid = np.asarray(sorted(zip(unic, ct),
                                   key=lambda v: 100000000 if v[0] == -1
                                   else le * v[1] + v[0]))
    unic = sorted_cid[:, 0]

    markers, sizes, palette = get_pms(unic)

    sorted_images = sorted(result_table, key=lambda v: np.where(unic == v[2])[0][0] * le + v[1])

    whole_image = np.zeros((grid_size * img_rows, grid_size * img_cols))
    for idx, data in enumerate(sorted_images):
        imid = data[0]
        img = images[imid, :]
        row = idx % grid_size * img_rows
        col = idx // grid_size * img_cols
        whole_image[row: row + img_rows, col: col + img_cols] = img.reshape((img_rows, img_cols))
        cid = result_table[imid, 2]
        if cid != -1:
            # poly = Polygon(k * (np.array(pts) - cent) + cent, fill=True, closed=True, facecolor=color, alpha=0.2)
            r = Rectangle((col, row), img_cols, img_rows, facecolor=palette[cid], ec=palette[cid], lw=2, alpha=0.3)
            ax.add_patch(r)
            plt.scatter(col+img_rows*0.15, row+img_rows*0.15,  marker=markers[cid], color=palette[cid], s=para_dict['markersize'])

    ax.imshow(whole_image, cmap='gray')
    ax.axis('off')

    plt.tight_layout()
    # plt.show()
    plt.savefig(file + '.png', dpi=600, transparent=False)
