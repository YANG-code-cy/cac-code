from typing import Union
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd

from cac.cac_final import CAC
from cac.utils.color_marker import get_pms

matplotlib.use('TkAgg', force=True)
print("Switched to:", matplotlib.get_backend())

import numpy as np
from utils.utils import get_data
import seaborn as sns

if __name__ == '__main__':
    datasets = ['compound',]

    fig = plt.figure(figsize=(9, 5))
    for i, data_set_name in enumerate(datasets):
        np.random.seed(1024)
        input_table = get_data(data_set_name)
        X = input_table[['x', 'y']].values
        kwargs = {'max_iter': 500, 'max_del_point': 5, 'link_threshold': -1,
                  'ftype': None, 'K': 20, 'lr': 1e-0}
        cac = CAC(X, **kwargs)
        cac.cluster(debug=lambda x: False, plot='figs/' + data_set_name)

        result = CAC.getResult(cac.p2c, cac.src_data)
        result = pd.DataFrame(result, columns=['p', 'c', 'x', 'y'])
        result.to_csv('figs/result.csv')
        # result = pd.read_csv('figs/result.csv')
        markers, sizes, palette = get_pms(result['c'].unique())
        plt.clf()
        sns.scatterplot(result, x='x', y='y', hue='c', palette=palette, style='c', markers=markers)
        plt.ylim((-0.1, 1.1))
        plt.xlim((-0.1, 1.1))
        plt.savefig('figs/' + data_set_name+'final.png', dpi=600, transparent=False)
