from typing import Optional, Callable

from scipy.cluster.hierarchy import linkage, fcluster
from scipy.io import arff
import pandas as pd
from sklearn.cluster import AffinityPropagation, Birch, DBSCAN, MeanShift, estimate_bandwidth, OPTICS, \
    SpectralClustering
from sklearn.cluster._hdbscan import hdbscan
from sklearn.mixture import GaussianMixture

from cac.CDC import CDC
from forest_fire_clustering import FFC


def get_data(file_name: str) -> Optional[pd.DataFrame]:
    data = arff.loadarff(open(file_name, encoding='utf8'))[0]
    input_table = pd.DataFrame(data)
    input_table = input_table.rename(columns=dict((k, v) for k, v in zip(input_table.columns, ['x', 'y', 'c'])))
    return input_table


def cdc_pred(X, k_num, ratio):
    return CDC(k_num, ratio, X.values).astype(int)


def ffc_pred(X, n_neighbors=20, fire_temp=1, num_permute=500, ):
    ffc = FFC(n_neighbors=n_neighbors, fire_temp=fire_temp, num_permute=num_permute)
    ffc.preprocess(X)
    ffc.fit(fire_temp=fire_temp)
    return ffc.cluster_labels.astype(int)


cluster_methods_kws: dict[int, dict[str, dict[str, Callable]]] = {
    0: {
        'Affinity Propagation': {
            # damping in (0.5, 1, 0.025)
            # preference in (-100, 100, 5)
            'alg': lambda X: AffinityPropagation(damping=0.85,
                                                 preference=-5,
                                                 random_state=42, convergence_iter=1000).fit_predict(X),
        },
        'BIRCH': {
            # n_clusters in (2, 41, 2)
            # threshold in (0.1, 1, 0.05)
            'alg': lambda X: Birch(n_clusters=22, threshold=0.1).fit_predict(X),
        },
        'CDC': {
            # 'k_num': (2, 50, 1),
            # 'ratio': (0.05, 1, 0.05)
            'alg': lambda X: cdc_pred(X, k_num=39, ratio=0.45),
            # Global best parameters: {'k_num': 39, 'ratio': 0.45}
            # Maximum v_measure_score sum: 3.8305
        },
        'DBSCAN': {
            # eps in (0.05, 0.5, 0.05)
            # min_sample in (3, 40, 1)
            'alg': lambda X: DBSCAN(eps=0.05, min_samples=3).fit_predict(X),
        },
        'Forest Fire': {
            # n_neighbors in (5, 100, 10)
            # fire_temp in (1, 100, 5)
            # num_permute in (10, 200, 10)
# Best parameters: {'fire_temp': 96, 'method': 'umap', 'n_jobs': 2, 'n_neighbors': 5, 'num_permute': 190}
# Highest cumulative v_measure_score score: 5.555108687445442
            'alg': lambda X: ffc_pred(X, n_neighbors=5, fire_temp=96, num_permute=190),
        },
        'Gaussian Mixture': {
            # n_components in (2, 50)
            # covariance_type in ['full',"tied','diag','spherical']
            'alg': lambda X: GaussianMixture(n_components=9, covariance_type='full').fit_predict(X),
        },
        'HDBSCAN': {
            # min_clusters_sizes in (2, 20, 1)
            # min_samples_list in (2, 20, 1)
            'alg': lambda X: hdbscan.HDBSCAN(min_cluster_size=11, min_samples=2).fit_predict(X),
        },
        'Mean Shift': {
            # quantile in (0.1, 0.5, 0.05)
            # n_samples in (30, 150, 10)
            'alg': lambda X: MeanShift(bandwidth=estimate_bandwidth(X, quantile=0.1, n_samples=30)).fit_predict(X),
        },
        'OPTICS': {
            # min_samples in (5, 50, 5)
            # max_eps in (0.5, 5, 0.25)
            'alg': lambda X: OPTICS(min_samples=30, max_eps=4.75).fit_predict(X),
        },
        'Spectral Clustering': {
            # n_cluster in (2, 15, 1)
            # affinity in ['nearest_neighbors','rbf']
            'alg': lambda X: SpectralClustering(n_clusters=4, affinity='nearest_neighbors').fit_predict(X),
        },
        'Ward': {
            # t in (2, 15, 1)
            # linkage in ['ward','single','complete',average']
            'alg': lambda X: fcluster(linkage(X, method='ward'), t=2, criterion='distance'),
        },
    },
    1: {
        'Affinity Propagation': {
            'alg': lambda X: AffinityPropagation(damping=0.65,
                                                 preference=-5,
                                                 random_state=42, convergence_iter=1000).fit_predict(X),
        },
        'BIRCH': {
            'alg': lambda X: Birch(n_clusters=6, threshold=0.1).fit_predict(X),
        },
        'CDC': {
            'alg': lambda X: cdc_pred(X, k_num=6, ratio=0.6),
            # Global best parameters: {'k_num': 6, 'ratio': 0.6000000000000001}
            # Maximum v_measure_score sum: 1.8748
        },
        'DBSCAN': {
            'alg': lambda X: DBSCAN(eps=0.05, min_samples=3).fit_predict(X),
        },
        'Forest Fire': {
            'alg': lambda X: ffc_pred(X, n_neighbors=25, fire_temp=16, num_permute=60),
        },
        'Gaussian Mixture': {
            'alg': lambda X: GaussianMixture(n_components=7, covariance_type='full', random_state=42).fit_predict(X),
        },
        'HDBSCAN': {
            'alg': lambda X: hdbscan.HDBSCAN(min_cluster_size=5, min_samples=2).fit_predict(X),
        },
        'Mean Shift': {
            'alg': lambda X: MeanShift(bandwidth=estimate_bandwidth(X, quantile=0.2, n_samples=30)).fit_predict(X),
        },
        'OPTICS': {
            'alg': lambda X: OPTICS(min_samples=10, max_eps=2.0).fit_predict(X),
        },
        'Spectral Clustering': {
            'alg': lambda X: SpectralClustering(n_clusters=4, affinity='nearest_neighbors').fit_predict(X),
        },
        'Ward': {
            'alg': lambda X: fcluster(linkage(X, method='ward'), t=9, criterion='distance'),
        },
    }
}
