import os

import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt

from cac.utils.color_marker import get_pms
from cac.utils.utils import get_data, dataset_name_map
from exp5_config import cluster_methods_kws

if __name__ == '__main__':
    datasets = [
        ('3-spiral', 'smile3', 'jain',
         'triangle1', 'spherical_6_2', 'twenty'),
        ('compound', 'aggregation')
    ]

    for i_group, cluster_methods_dict in cluster_methods_kws.items():
        for X_name in datasets[i_group]:
            data = dataset_name_map[X_name.lower()]()
            X = pd.DataFrame(data)
            X = X.rename(columns=dict((k, v) for k, v in zip(X.columns, ['x', 'y', 'c'])))
            X[['x', 'y']] = X[['x', 'y']] - X[['x', 'y']].min()
            X[['x', 'y']] = X[['x', 'y']] / X[['x', 'y']].max()
            for alg_name in (list(cluster_methods_dict.keys()) + ['EVC']):
                file = r'exp#5/%s-%s-%s' % (str(i_group), alg_name, X_name)
                print(file)
                if alg_name not in cluster_methods_dict.keys():
                    continue
                if not os.path.exists(file+'.csv') or True:
                    method_dict = cluster_methods_dict[alg_name]
                    pred_c = method_dict['alg'](X[['x', 'y']])
                    X_copy = X.copy()
                    X_copy['pred_c'] = pred_c
                    X_copy.to_csv(file+'.csv')

                result = pd.read_csv(file+'.csv')
                fig, ax = plt.subplots(figsize=(2.25, 2))
                markers, sizes, palette = get_pms(result['pred_c'].unique())
                sns.scatterplot(result, x='x', y='y', hue='pred_c', ax=ax,
                                palette=palette, markers=markers,
                                style='pred_c')
                ax.axis('off')
                ax.legend().set_visible(False)
                plt.savefig('%s.png' % file, dpi=600, transparent=False)
                plt.close()